module.exports = require('.').tsx;
