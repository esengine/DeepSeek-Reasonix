module golang.org/x/image

go 1.25.0

require golang.org/x/text v0.38.0
